	<!<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<header class="header" role="banner" itemscope="itemscope" itemtype="http://schema.org/WPHeader">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-xs-12">
					<div class="site-branding">
					<a href="http://uniwebau.tech/traditionalshaolin/" target="_blank" rel="home">	
									<img src="images/logo.png" alt="logo">
								</a>
																		</div>
				</div>
																	<div class="col-md-7  col-xs-12 header-right">
					<aside id="text-14" class="widget widget_text">			<div class="textwidget"><div class="row extra-info">
<div class="col-md-1 hidden-xs"></div>
<div class="col-md-4 col-xs-12"><i class="fa fa-phone"></i>CALL US FREE<br>
0418 664 923</div>
<div class="col-md-5 col-xs-12"><i class="fa fa-envelope"></i>EMAIL US<br>
jahungchi@bigpond.com</div>
<div class="col-md-2 col-xs-12"><!--<img class="alignnone size-full wp-image-75129" src="http://uniwebau.tech/traditionalshaolin/wp-content/uploads/2019/08/login.png" alt="" width="129" height="45">--></div>
</div>
</div>
		</aside>				</div>
							</div>
		</div>
	</header>