<footer class="footer">
	
	<div class="copyright">
			<div class="container">
				Copyright © 2019, <a href="#">Traditional Shaolin Kung Fu Academy</a>. All Right Reserved.			</div>
		</div>
</footer>

